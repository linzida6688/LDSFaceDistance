//
//  FDFaceToCameraDistance.h
//  FaceDistanceDemo
//
//  Created by Lindashuai on 2020/11/12.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import "FDDefine.h"

@interface FDConfiguration : NSObject

//default is 0, NSIntegerMax for ever
@property(nonatomic, assign) NSInteger repeatCount;

//must bigger than 1.0s
@property(nonatomic, assign) NSTimeInterval timeInterval;    // 检测

//default firstRepeatDelay = timeInterval, must bigger than 1.0s
@property(nonatomic, assign) NSTimeInterval firstRepeatDelay;    // 监测间隔

@end

@interface FDFaceToCameraDistance : NSObject

+ (void)cameraAuthorization:(void(^)(BOOL authorized))block; //判断相机是否授权

+ (BOOL)isSupported;

+ (BOOL)isCaptureDeviceSupport;

+ (BOOL)authorized;

+ (void)startWithConfiguration:(FDConfiguration *)configuration detectBlock:(FDFaceDistanceBlock)block;

+ (void)setStartWithoutFirstBlock:(void(^)(void))block;

+ (void)stop;

+ (AVAuthorizationStatus)cameraAuthorizationStatus;

@end
