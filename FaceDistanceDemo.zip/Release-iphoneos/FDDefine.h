//
//  FDDefine.h
//  FaceDistanceDemo
//
//  Created by Lindashuai on 2020/11/12.
//

#ifndef FDDefine_h
#define FDDefine_h

/*
 success: 是否检测到人脸
 distance: 人脸与摄像头的距离
 */
typedef void(^FDFaceDistanceBlock)(BOOL success, NSUInteger distance);

@protocol FDDetectorDelegate <NSObject>

+ (BOOL)isSupported;

- (void)setCompleteBlock:(FDFaceDistanceBlock)block;

- (void)start;

- (void)stop;

- (void)pause;

- (void)resume;

@end


#endif /* FDDefine_h */
