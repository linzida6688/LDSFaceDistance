//
//  AppDelegate.h
//  123
//
//  Created by Lindashuai on 2020/11/15.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

