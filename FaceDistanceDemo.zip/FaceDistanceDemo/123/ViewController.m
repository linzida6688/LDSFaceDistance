//
//  ViewController.m
//  123
//
//  Created by Lindashuai on 2020/11/15.
//

#import "ViewController.h"
#import "FDFaceToCameraDistance.h"

@interface ViewController ()

@property(nonatomic, strong) UILabel *label;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.label];
    
    __weak typeof(self) weakSelf = self;
    [FDFaceToCameraDistance startWithConfiguration:[self createFDConfig] detectBlock:^(BOOL success, NSUInteger distance) {
        NSLog(@"face distance %ld cm", distance);
        if(distance > 100) {
            NSLog(@"has not get you face");
        } else {
            weakSelf.label.text = [NSString stringWithFormat:@"face distance is %ld cm", distance];
        }
    }];
}

- (FDConfiguration *)createFDConfig {
    FDConfiguration *config = [[FDConfiguration alloc] init];
    config.repeatCount = NSIntegerMax;
    config.firstRepeatDelay = 5.0;
    config.timeInterval = 2.0;
    return config;
}

- (UILabel *)label {
    if(_label == nil) {
        _label = [[UILabel alloc]initWithFrame:self.view.bounds];
        _label.textColor = [UIColor blackColor];
        _label.font = [UIFont systemFontOfSize:30];
        _label.textAlignment = NSTextAlignmentCenter;
    }
    return _label;
}

@end
