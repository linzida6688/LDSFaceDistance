//
//  SceneDelegate.h
//  123
//
//  Created by Lindashuai on 2020/11/15.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

